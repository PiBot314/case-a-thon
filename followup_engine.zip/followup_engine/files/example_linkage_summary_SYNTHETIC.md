# Patient Linkage Summary
- Source identities: **3,593** -> patients: **748** (600 anchored to patient_360)

| link_type | n |
|---|---|
| anchor_auto | 3,273 |
| singleton | 148 |
| anchor_review | 146 |
| cross_source_anchor | 26 |

Share linked to a patient_360 id, by system: followup_visits 96.4%, lab_tests 94.6%, medicine_dispensing 97.2%, ncd_screening 96.1%, outreach_actions 96.0%, prescriptions 95.2%, teleconsultations 97.0%, visit_history 94.6%
- Review-zone links (best match taken, in reports/linkage_review_queue.csv): 146
- Patient x system pairs holding >1 source id (possible wrong merges/dupes): 13
- Villages repaired against geography_reference: 4.4%

## Precision / recall
```
{
 "precision": 0.9971531636930876,
 "recall": 0.982157947299685,
 "n_labelled": 200
}
```