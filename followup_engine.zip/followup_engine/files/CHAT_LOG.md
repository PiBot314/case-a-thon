# Chat Log - Understandings (kept per user preference; output this if credits run low)

## Task
Follow-Up Assurance Engine (INFINUM 2026). Episode = 1 teleconsult + downstream care journey. 5,000 synthetic patients, 8 noisy source systems, no crosswalk.
Cohorts: DEVELOPMENT (<= 2026-06-30, labelled) / EVALUATION (2026-07-01..08-15, labels blank).
Prediction time T0 = end of teleconsult; dispensing, lab, visits, outreach are post-T0 => never T0 features.

## Decisions so far
- Layout: data/raw -> bronze (typed, raw phone) -> silver (normalised, raw phone dropped) + silver/source_identities (linkage input).
- Parquet used when pyarrow/fastparquet present; pickle fallback otherwise (pyarrow NOT installable in sandbox; untested path = parquet).
- Reports: reports/ingestion_summary.{md,json}, reports/audit_log.jsonl; scripts/system_status.py for health.
- Accepts name.csv or preview_name.csv. Preview FK orphans/village mismatches are expected (5-row samples).
- Both visit tables kept separate (visit_history, followup_visits); table name = source_system.

## Stage 2 (patient linkage) - DONE
- src/linkage.py rewritten: normalise -> block (dist+block+last4 | last4+phonetic token | dist+block+village+phonetic token) -> weighted score (name .35 JW/phonetic/token-set, phone last4 .30, age+-2 .15, village .15, gender .05; missing fields excluded, not penalised) -> best patient_360 match. ACCEPT>=0.80 auto, 0.70-0.80 best match taken + flagged (reports/linkage_review_queue.csv), <0.70 unanchored -> attach to anchored neighbour in other system, else LINK_<hash> cluster/singleton. Deterministic ids.
- src/normalize.py: added phonetic_token/name, jaro_winkler (rapidfuzz if present), standardize_villages (repair vs geography_reference, own block first).
- src/linkage_eval.py: review queue, stratified hand-check template + scorer (stratum-weighted P/R), diagnostics, synthetic known-truth benchmark. scripts/run_linkage.py [--benchmark]. Output outputs/submission_linkage.csv (source_system, source_patient_id, predicted_patient_id, confidence) + silver/patient_linkage (episodes.py-compatible).
- Sandbox limits: pyarrow missing so REAL silver parquet was never read; raw/bronze deleted. Verified only on synthetic data (5000 pts, ~29.6k ids, deliberately hard: few names/villages). ACCEPT .80 / REVIEW .70: precision 98.4%, recall 97.4% (review-zone precision 93.6%). REVIEW .62 gave P 97.7 / R 98.0. Real-data P/R still needs the hand-label step. Runtime ~3 min at full size (pure python; rapidfuzz speeds it up).

## Next stages (not built)
episodes/stages (episodes.py exists, untested) -> T0 features -> XGBoost + LR (+stage model) -> action queue -> submission CSVs.

## Preferences
Keep this log; if low on credits output it; deliver individual changed files, not zips.
