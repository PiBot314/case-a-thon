# Chat Log - Understandings (kept per user preference; output this if credits run low)

## Task
Follow-Up Assurance Engine (INFINUM 2026). Episode = 1 teleconsult + downstream care journey. 5,000 synthetic patients, 8 noisy source systems, no crosswalk.
Cohorts: DEVELOPMENT (<= 2026-06-30, labelled) / EVALUATION (2026-07-01..08-15, labels blank).
Prediction time T0 = end of teleconsult; dispensing, lab, visits, outreach are post-T0 => never T0 features.

## Decisions so far
- Layout: data/raw -> bronze (typed, raw phone) -> silver (normalised, raw phone dropped) + silver/source_identities (linkage input).
- Parquet used when pyarrow/fastparquet present; pickle fallback otherwise (pyarrow NOT installable in sandbox; untested path = parquet).
- Reports: reports/ingestion_summary.{md,json}, reports/audit_log.jsonl; scripts/system_status.py for health.
- Accepts name.csv or preview_name.csv. Preview FK orphans/village mismatches are expected (5-row samples).
- Both visit tables kept separate (visit_history, followup_visits); table name = source_system.

## Next stages (not built)
linkage -> episodes/stages -> T0 features -> XGBoost + LR (+stage model) -> action queue -> submission CSVs.

## Preferences
Keep this log; if low on credits output it; deliver individual changed files, not zips.
